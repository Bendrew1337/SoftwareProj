package com.example.sensorui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class setPointConfigure extends AppCompatActivity {

    TextView currentWarningValue;
    TextView currentDangerValue;

    EditText inputWarningValue;
    EditText inputDangerValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_point_configure);

        currentWarningValue = findViewById(R.id.textView_currentWarnValue);
        currentDangerValue = findViewById(R.id.textView_currentDangerValue);
        inputWarningValue = findViewById(R.id.editText_inputWarnValue);
        inputDangerValue = findViewById(R.id.editText_inputDangerValue);


        // get current threhold values

        Intent intent = getIntent();

        currentWarningValue.setText(intent.getStringExtra("warningThreshold"));
        currentDangerValue.setText(intent.getStringExtra("dangerThreshold"));

        // initially display the current threshold values in the edit text boxes

        inputWarningValue.setText(currentWarningValue.getText());
        inputDangerValue.setText(currentDangerValue.getText());

    }



    public void openDataLoggingSetup(View view)
    {
        Intent intent = new Intent(this, dataLoggingSetup.class);
        startActivity(intent);
    }

    public void openAlarmTestSetup(View view)
    {
        Intent intent = new Intent(this, alarmTestSetup.class);
        startActivity(intent);
    }

    public void openMain(View view)
    {

        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("newWarningThreshold",inputWarningValue.getText().toString());
        intent.putExtra("newDangerThreshold", inputDangerValue.getText().toString());
        startActivity(intent);
    }
}
