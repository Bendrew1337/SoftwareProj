package com.example.sensorui;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

import static android.content.ContentValues.TAG;

/**
 * Created by a00695954 on 4/11/2018.
 */

public class AcceptTask extends AsyncTask<String, Void, String> {

    private final BluetoothServerSocket mmServerSocket;
    private BluetoothAdapter mBluetoothAdapter;
    private Handler mHandler;
    private Context mainActi;
    private String id;

    private InputStream mmInStream;
    private OutputStream mmOutStream;
    private byte[] mmBuffer; // mmBuffer store for the stream
    String test = new String();//

    // Defines several constants used when transmitting messages between the
    // service and the UI.
    private interface MsgConstants {
        public static final int MESSAGE_READ = 0;
        public static final int MESSAGE_WRITE = 1;
        public static final int MESSAGE_TOAST = 2;

    }

    AcceptTask(BluetoothAdapter BA, Handler hand, Context context, String deviceID){
        mBluetoothAdapter = BA;
        UUID MY_UUID = new UUID(80087355,0);
        id = deviceID;
        mHandler = hand;
        mainActi = context;

        // Use a temporary object that is later assigned to mmServerSocket
        // because mmServerSocket is final.
        BluetoothServerSocket tmp = null;
        try {
            // MY_UUID is the app's UUID string, also used by the client code.
            tmp = mBluetoothAdapter.listenUsingRfcommWithServiceRecord("MyOBEX", MY_UUID);
        } catch (IOException e) {
            Log.e(TAG, "Socket's listen() method failed", e);
        }
        mmServerSocket = tmp;

    }


    @Override
    protected String doInBackground(String... urls) {
        /***/
        BluetoothSocket socket = null;
        // Keep listening until exception occurs or a socket is returned.
        while (true) {
            try {
                socket = mmServerSocket.accept();
            } catch (IOException e) {
                Log.e(TAG, "Socket's accept() method failed", e);
                break;
            }

            if (socket != null) {
                // A connection was accepted.
                try {
                    mmServerSocket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
            }
        }

        // Get the input and output streams; using temp objects because
        // member streams are final.
        InputStream tmpIn = null;
        OutputStream tmpOut = null;

        try {
            tmpIn = socket.getInputStream();
        } catch (IOException e) {
            Log.e(TAG, "Error occurred when creating input stream", e);
        }
        try {
            tmpOut = socket.getOutputStream();
        } catch (IOException e) {
            Log.e(TAG, "Error occurred when creating output stream", e);
        }
        mmInStream = tmpIn;
        mmOutStream = tmpOut;


        mmBuffer = new byte[1024];
        int numBytes; // bytes returned from read()


        publishProgress();

        // Keep listening to the InputStream until an exception occurs.
        while (true) {
            try {
                // Read from the InputStream.
                numBytes = mmInStream.read(mmBuffer);
                // Send the obtained bytes to the UI activity.
                Message readMsg = mHandler.obtainMessage(AcceptTask.MsgConstants.MESSAGE_READ, numBytes, -1, mmBuffer);
                readMsg.sendToTarget();

            } catch (IOException e) {
                Log.d(TAG, "Input stream was disconnected", e);
                break;
            }
        }

        return null;

    }

    @Override
    protected void onPreExecute() {
        /** Disable connect button that started this task */
        Toast toast = Toast.makeText(mainActi, "Connecting to Sensor " + id, Toast.LENGTH_LONG);
        toast.show();
    }

    @Override
    protected void onPostExecute(String result) {
        /** Enable connect button that started this task */
        Toast toast = Toast.makeText(mainActi, "Sensor " + id + " No longer communicating", Toast.LENGTH_LONG);
        toast.show();
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        Toast toast = Toast.makeText(mainActi, "Sensor " + id + " Connected", Toast.LENGTH_LONG);
        toast.show();

    }


}
