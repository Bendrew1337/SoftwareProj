package com.example.sensorui;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.FragmentManager;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Message;
import android.os.Parcelable;
import android.provider.SyncStateContract;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Set;
import java.util.logging.Handler;

public class MainActivity extends AppCompatActivity {
	
	//ken code
    TextView sensorALabel;
    TextView sensorAStatus;
    public TextView sensorAMagnitude;
    TextView sensorBLabel;
    TextView sensorBStatus;
    public TextView sensorBMagnitude;
    public float sensorASignalStrength;          // Electric field strength from ADC (0 - 100%)
    public float sensorBSignalStrength;

    static int dangerThreshold = 4;           // Electric field danger level threshold
    static int warningThreshold = 2;          // Electric field warning level threshold
	
	// Andrew code
	BluetoothDevice myComp = null;
    BluetoothAdapter mBluetoothAdapter;

    MediaPlayer alarmSound;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sensorALabel = (TextView)findViewById(R.id.textView_sensorA);
        sensorAStatus = (TextView)findViewById(R.id.textView_sensorAStatus);
        sensorAMagnitude = (TextView)findViewById(R.id.textView_sensorAMag);

        sensorBLabel = (TextView)findViewById(R.id.textView_sensorB);
        sensorBStatus = (TextView)findViewById(R.id.textView_sensorBStatus);
        sensorBMagnitude = (TextView)findViewById(R.id.textView_sensorBMag);

        alarmSound = MediaPlayer.create(this, R.raw.alarm);


        // Get Extras from set point activity
        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if(extras != null){
            warningThreshold = Integer.parseInt(extras.getString("newWarningThreshold"));
            dangerThreshold = Integer.parseInt(extras.getString("newDangerThreshold"));
        }

        // Andrew code
        BluetoothSetup();

		// Test signal for alarm
        sensorASignalStrength = 0;
        sensorBSignalStrength = 0;

        setSensorStatus(sensorASignalStrength, sensorBSignalStrength);


    }



    public void alarmTrigger(){
        //final MediaPlayer alarmSound = MediaPlayer.create(this, R.raw.alarm);
        if (sensorASignalStrength >= dangerThreshold || sensorBSignalStrength >= dangerThreshold) {
            alarmSound.start();
        } else {
            if(alarmSound.isPlaying())
                alarmSound.pause();
        }
    }


    // Update the sensor status based on the signal strength received from the Sensor Unit ADC
    public void setSensorStatus(float aStrength, float bStrength)
    {
        alarmTrigger();
        sensorAMagnitude.setText(String.valueOf(sensorASignalStrength));
        sensorBMagnitude.setText(String.valueOf(sensorBSignalStrength));

        if(sensorASignalStrength >= dangerThreshold){
            sensorALabel.setBackgroundResource(R.color.red);
            sensorAStatus.setBackgroundResource(R.color.red);
            sensorAMagnitude.setBackgroundResource(R.color.red);
            sensorAStatus.setText(R.string.string_danger);
        }
        else{
             if(sensorASignalStrength >= warningThreshold){
                 sensorALabel.setBackgroundResource(R.color.yellow);
                 sensorAStatus.setBackgroundResource(R.color.yellow);
                 sensorAMagnitude.setBackgroundResource(R.color.yellow);
                 sensorAStatus.setText(R.string.string_warning);
             }
             else{
                 sensorALabel.setBackgroundResource(R.color.green);
                 sensorAStatus.setBackgroundResource(R.color.green);
                 sensorAMagnitude.setBackgroundResource(R.color.green);
                 sensorAStatus.setText(R.string.string_safe);
             }
        }

        if(sensorBSignalStrength >= dangerThreshold){
            sensorBLabel.setBackgroundResource(R.color.red);
            sensorBStatus.setBackgroundResource(R.color.red);
            sensorBMagnitude.setBackgroundResource(R.color.red);
            sensorBStatus.setText(R.string.string_danger);
        }
        else{
            if(sensorBSignalStrength >= warningThreshold){
                sensorBLabel.setBackgroundResource(R.color.yellow);
                sensorBStatus.setBackgroundResource(R.color.yellow);
                sensorBMagnitude.setBackgroundResource(R.color.yellow);
                sensorBStatus.setText(R.string.string_warning);
            }
            else{
                sensorBLabel.setBackgroundResource(R.color.green);
                sensorBStatus.setBackgroundResource(R.color.green);
                sensorBMagnitude.setBackgroundResource(R.color.green);
                sensorBStatus.setText(R.string.string_safe);
            }
        }
    }

    public void openSetPointSetup(View view)
    {
        Intent intent = new Intent(this, setPointConfigure.class);
        intent.putExtra("warningThreshold",String.valueOf(warningThreshold));
        intent.putExtra("dangerThreshold", String.valueOf(dangerThreshold));
        startActivity(intent);
    }

    public void openDataLoggingSetup(View view)
    {
        Intent intent = new Intent(this, dataLoggingSetup.class);
        startActivity(intent);
    }

    public void openAlarmTestSetup(View view)
    {
        Intent intent = new Intent(this, alarmTestSetup.class);
        startActivity(intent);
    }
    // Create a BroadcastReceiver for ACTION_FOUND.
    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                // Discovery has found a device. Get the BluetoothDevice
                // object and its info from the Intent.
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                //myComp = device;
                String deviceName = device.getName();
                String deviceHardwareAddress = device.getAddress(); // MAC address
                //text.setText("Found: " + deviceName); /** debug purposes */

            }
            else if (BluetoothAdapter.ACTION_DISCOVERY_STARTED.equals(action)){
                int s = 5;
            }
            else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)){
                int s = 6;
            }
            else if (BluetoothAdapter.ACTION_STATE_CHANGED.equals(action)){
                int s = 7;
            }


        }
    };
/**  This is to save the instance... dont know how to use it though
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putAll(savedInstanceState);

        super.onSaveInstanceState(savedInstanceState);
    }*/

    @Override
    protected void onDestroy() {
        super.onDestroy();

        // Don't forget to unregister the ACTION_FOUND receiver.
        unregisterReceiver(mReceiver);
    }




    // Listen for a bluetooth connection from paired sensor device
    public void restartRx1 (View view){
         AcceptTask accept = new AcceptTask(mBluetoothAdapter, mHandler, this, "A");
        accept.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR,null);    // Communication will happen in a background task
    }

    public void restartRx2 (View view){
        AcceptTask accept = new AcceptTask(mBluetoothAdapter, mHandler2, this, "B");
        accept.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR,null);    // Communication will happen in a background task
    }

    private void BluetoothSetup(){
        // Get the bluetooth adapter
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter == null) {
            // Device doesn't support Bluetooth
        }

        int REQUEST_ENABLE_BT = 1;

        // Enable BlueTooth
        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);

            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        }

        // Search for list of paired devices. If the desired device's MAC is already known, then there is no need to discover
        Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();
        if (pairedDevices.size() > 0) {
            // There are paired devices. Get the name and address of each paired device.
            for (BluetoothDevice device : pairedDevices) {
                String deviceName = device.getName();
                String deviceHardwareAddress = device.getAddress(); // MAC address
                if (deviceName.contains("bone")){
                    myComp = device;
                    //text.setText("Found:: " + deviceName + " " + deviceHardwareAddress);
                }
            }
        }

        // Register for broadcasts when a device is discovered.
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        filter.addAction(BluetoothDevice.ACTION_FOUND);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        registerReceiver(mReceiver, filter);


        // Permission must also be requested at runtime just before starting discovery or devices cannot be discovered.
        int MY_PERMISSIONS_REQUEST_ACCESS_COARSE_LOCATION = 1;
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},
                MY_PERMISSIONS_REQUEST_ACCESS_COARSE_LOCATION);
        // Start discovering devices
        mBluetoothAdapter.startDiscovery();

    }

    // Handler for processing data between the Bluetooth connection
    @SuppressLint("HandlerLeak")
    private final android.os.Handler mHandler = new android.os.Handler() {
        @Override
        public void handleMessage(Message msg) {
            byte[] msgReceived = (byte[]) msg.obj;

            // construct a string from the valid bytes in the buffer
            String theMessage = new String(msgReceived, 0, msg.arg1);

            // convert message string to float
            int num = theMessage.indexOf(".");
            if(theMessage.indexOf(".", num + 1) == -1) {    // Because sometimes values get double-transmitted
                sensorASignalStrength = Float.parseFloat(theMessage);
                setSensorStatus(sensorASignalStrength, sensorBSignalStrength);

            }
            String shorter = theMessage.substring(0,5);
            sensorAMagnitude.setText(shorter);
        }
    };

    @SuppressLint("HandlerLeak")
    private final android.os.Handler mHandler2 = new android.os.Handler() {
        @Override
        public void handleMessage(Message msg) {

            byte[] msgReceived = (byte[]) msg.obj;
            // construct a string from the valid bytes in the buffer
            String theMessage = new String(msgReceived, 0, msg.arg1);


            // convert message string to float
            int num = theMessage.indexOf(".");
            if(theMessage.indexOf(".", num + 1) == -1) {    // Because sometimes values get double-transmitted
                sensorBSignalStrength = Float.parseFloat(theMessage);
                setSensorStatus(sensorASignalStrength, sensorBSignalStrength);

            }
            String shorter = theMessage.substring(0,5);
            sensorBMagnitude.setText(shorter);
        }
    };


}
