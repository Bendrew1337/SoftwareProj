package com.example.sensorui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class dataLoggingSetup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_logging_setup);
    }

    public void openSetPointSetup(View view)
    {
        Intent intent = new Intent(this, setPointConfigure.class);
        startActivity(intent);
    }

    public void openAlarmTestSetup(View view)
    {
        Intent intent = new Intent(this, alarmTestSetup.class);
        startActivity(intent);
    }

    public void openMain(View view)
    {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
